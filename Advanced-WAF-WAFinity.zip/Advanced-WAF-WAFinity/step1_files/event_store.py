"""SQLite-backed event store for WAF detections (Step 1 of the dashboard)."""
import re
import sqlite3
import threading
import uuid
from datetime import datetime
from pathlib import Path

# <repo>/logs/waf_events.db  (works no matter where you run `python app.py` from)
BASE_DIR = Path(__file__).resolve().parents[3]
DB_PATH = BASE_DIR / "logs" / "waf_events.db"

_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id  TEXT NOT NULL,
    ts          TEXT NOT NULL,          -- ISO 8601, e.g. 2026-10-15T14:03:22
    client_ip   TEXT,
    method      TEXT,
    path        TEXT,
    payload     TEXT,
    status      TEXT NOT NULL,          -- valid | malicious | obfuscated
    action      TEXT NOT NULL,          -- allowed | blocked
    detected_by TEXT,                   -- signature | ml | none
    category    TEXT,                   -- SQLi | XSS | SSRF | HTML Injection | Obfuscated | Other | None
    ml_score    REAL
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
CREATE INDEX IF NOT EXISTS idx_events_action ON events(action);
"""

# Lightweight categorizer (the signature checker only returns a verdict, not a type)
_CATEGORY_RULES = [
    ("SQLi", r"\b(union|select|insert|drop|delete|update)\b.*\bfrom\b|\bunion\s+select\b|\bor\s+['\"]?1['\"]?\s*=\s*['\"]?1|\bsleep\s*\(|\bwaitfor\b|\bbenchmark\s*\(|--|/\*"),
    ("XSS", r"<\s*script|<\s*img|<\s*svg|<\s*iframe|on\w+\s*=|javascript:|document\.cookie|alert\s*\(|eval\s*\("),
    ("SSRF", r"file://|gopher://|169\.254\.|127\.0\.0\.1|localhost|metadata\.google"),
    ("HTML Injection", r"<\s*(div|span|form|input|body|html|table|style|a)\b"),
]


def categorize(payload: str, status: str) -> str:
    if status == "valid":
        return "None"
    for name, pattern in _CATEGORY_RULES:
        if re.search(pattern, payload or "", re.IGNORECASE):
            return name
    return "Obfuscated" if status == "obfuscated" else "Other"


def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _lock, _connect() as conn:
        conn.executescript(SCHEMA)


def record_event(*, payload, status, action, detected_by, client_ip=None,
                 method="POST", path="/check_request", ml_score=None) -> str:
    """Insert one event and return its request_id."""
    request_id = uuid.uuid4().hex[:12]
    category = categorize(payload, status)
    with _lock, _connect() as conn:
        conn.execute(
            """INSERT INTO events (request_id, ts, client_ip, method, path, payload,
                                   status, action, detected_by, category, ml_score)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (request_id, datetime.now().isoformat(timespec="seconds"), client_ip,
             method, path, (payload or "")[:2000], status, action, detected_by,
             category, ml_score),
        )
    return request_id
