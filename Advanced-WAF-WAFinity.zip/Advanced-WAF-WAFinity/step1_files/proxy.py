import logging
import os

from flask import Blueprint, request, jsonify

from src.hybrid_waf.utils.signature_checker import check_signature
from src.hybrid_waf.utils.event_store import init_db, record_event

# --- Legacy text log (kept so nothing else breaks) ---
os.makedirs("logs", exist_ok=True)
waf_logger = logging.getLogger("waf_detections")
waf_logger.setLevel(logging.INFO)
if not waf_logger.handlers:  # avoid duplicate handlers on Flask debug reload
    fh = logging.FileHandler("logs/detections.log")
    fh.setFormatter(logging.Formatter("%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    waf_logger.addHandler(fh)

init_db()  # creates logs/waf_events.db + table if missing

proxy_bp = Blueprint("proxy", __name__)


def _client_ip():
    # Behind a reverse proxy, trust X-Forwarded-For only if you control that proxy.
    return request.headers.get("X-Forwarded-For", request.remote_addr)


@proxy_bp.route("/check_request", methods=["POST"])
def check_request():
    data = request.get_json(silent=True) or {}
    user_input = data.get("user_request", "")
    uri = data.get("uri", user_input)
    get_data = data.get("get_data", "")
    post_data = data.get("post_data", "")
    ip = _client_ip()

    # --- Step 1: Signature-based detection ---
    signature_result = check_signature(user_input)

    if signature_result == "valid":
        waf_logger.info(f"{user_input!r} - valid")
        record_event(payload=user_input, status="valid", action="allowed",
                     detected_by="none", client_ip=ip)
        return jsonify({
            "status": "valid",
            "message": "All Clear! Your request passed our security checks with flying colors.✨",
        })

    if signature_result == "malicious":
        waf_logger.info(f"{user_input!r} - malicious(signature)")
        record_event(payload=user_input, status="malicious", action="blocked",
                     detected_by="signature", client_ip=ip)
        return jsonify({
            "status": "malicious",
            "message": "Critical Alert! Malicious pattern detected in your request.<br>Access Denied!🔒",
        })

    # --- Step 2: ML-based anomaly detection (obfuscated requests only) ---
    from src.hybrid_waf.utils.preprocessor import extract_features
    from src.hybrid_waf.utils.ml_checker import check_ml_prediction

    features = extract_features(uri, get_data, post_data)
    prediction = check_ml_prediction(features)
    is_malicious = prediction == 1

    waf_logger.info(f"{user_input!r} - {'malicious(ML)' if is_malicious else 'valid'}")
    record_event(payload=user_input, status="obfuscated",
                 action="blocked" if is_malicious else "allowed",
                 detected_by="ml", client_ip=ip)

    return jsonify({
        "status": "obfuscated",
        "ml_verdict": (
            "🚨 Threat Confirmed! AI Defense System Blocked Suspicious Activity.🔒"
            if is_malicious else
            "✅ Advanced AI Scan Complete: Request Verified Safe ✨"
        ),
        "message": "Suspicious Pattern Detected - Engaging Advanced AI Analysis...",
        "features": features,
    })
